"""Tencent Cloud COS MCP server (stdio transport).

Exposes upload/list/download tools backed by the official Tencent Cloud COS
Python SDK (cos-python-sdk-v5). Launched with its own ``.venv`` so its
dependencies stay isolated from the host jiuwenswarm environment (see
integration.json), mirroring the azure-blob-storage connector package.

Every account's instance of this connector shares the same Tencent COS
bucket/credentials - per-user isolation is enforced here, not by separate
Tencent-side credentials. ``TENCENT_COS_USER_PREFIX`` is set once per
container by deploy/provision_user.sh (never client- or agent-suppliable) and
every tool below unconditionally confines its target key under
``<prefix>/`` via ``_scope_key``/``_scope_prefix``, regardless of what the
caller (internal cloud-mirror code or the agent's own direct tool call)
asks for. The bucket is likewise always pinned to the connector's configured
default - no caller-supplied bucket override - since the whole isolation
story only holds for the one bucket it was set up for.
"""

from __future__ import annotations

import os

from qcloud_cos import CosConfig, CosServiceError, CosS3Client
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("tencent-cos")

_SECRET_ID = os.environ.get("TENCENT_COS_SECRET_ID", "").strip()
_SECRET_KEY = os.environ.get("TENCENT_COS_SECRET_KEY", "").strip()
_REGION = os.environ.get("TENCENT_COS_REGION", "").strip()
_DEFAULT_BUCKET = os.environ.get("TENCENT_COS_DEFAULT_BUCKET", "").strip()
# Fixed per-container isolation boundary - see module docstring. Empty means
# "no scoping" (e.g. a legacy single-tenant setup with no prefix configured).
_USER_PREFIX = os.environ.get("TENCENT_COS_USER_PREFIX", "").strip().strip("/")


def _client() -> CosS3Client:
    if not _SECRET_ID or not _SECRET_KEY:
        raise RuntimeError(
            "TENCENT_COS_SECRET_ID / TENCENT_COS_SECRET_KEY are not configured "
            "for this connector."
        )
    if not _REGION:
        raise RuntimeError("TENCENT_COS_REGION is not configured for this connector.")
    config = CosConfig(Region=_REGION, SecretId=_SECRET_ID, SecretKey=_SECRET_KEY)
    return CosS3Client(config)


def _resolve_bucket() -> str:
    # No caller-supplied override: every tool call is pinned to this
    # connector's own configured bucket, so the TENCENT_COS_USER_PREFIX
    # isolation below can't be sidestepped by pointing at a different bucket.
    if not _DEFAULT_BUCKET:
        raise ValueError(
            "TENCENT_COS_DEFAULT_BUCKET is not configured for this connector."
        )
    return _DEFAULT_BUCKET


def _scope_key(raw_key: str) -> str:
    """Clamp an object key under this connector's ``TENCENT_COS_USER_PREFIX``.

    Unconditionally prepends the prefix unless the key already starts with
    it - never rejects or tries to "detect" an escape attempt, since any
    string that doesn't already start with ``<prefix>/`` just gets nested
    one level deeper under it. That makes it impossible for any key, however
    constructed, to land outside the prefix.
    """
    key = (raw_key or "").strip().lstrip("/")
    if not _USER_PREFIX:
        return key
    prefix = f"{_USER_PREFIX}/"
    if key == _USER_PREFIX or key.startswith(prefix):
        return key
    return prefix + key


def _scope_prefix(raw_prefix: str | None) -> str:
    """Same clamp as ``_scope_key``, for list_objects' ``prefix`` argument
    (empty/None becomes exactly ``<prefix>/`` - i.e. "everything I own")."""
    return _scope_key(raw_prefix or "")


def _object_url(bucket: str, key: str) -> str:
    return f"https://{bucket}.cos.{_REGION}.myqcloud.com/{key}"


@mcp.tool()
def upload_file(local_path: str, object_key: str | None = None) -> str:
    """Upload a local file to Tencent COS and return its URL.

    Args:
        local_path: Absolute path to the local file to upload.
        object_key: Destination object key/path inside the bucket. Defaults
            to the local file's basename. Always confined under this
            account's own prefix regardless of what's passed here.
    """
    if not os.path.isfile(local_path):
        raise FileNotFoundError(f"local file not found: {local_path}")
    bucket_name = _resolve_bucket()
    key = _scope_key(object_key or os.path.basename(local_path))
    client = _client()
    # ACL="public-read": the bucket's own default ACL is private, so without
    # this the upload succeeds but the returned URL 403s on anonymous GET —
    # breaks any caller that hands this URL to a third party (e.g. a video
    # generation provider fetching a reference audio/video URL).
    client.upload_file(Bucket=bucket_name, LocalFilePath=local_path, Key=key, ACL="public-read")
    return _object_url(bucket_name, key)


@mcp.tool()
def upload_text(content: str, object_key: str, content_type: str = "text/plain") -> str:
    """Upload text content directly to Tencent COS and return its URL.

    Args:
        content: Text content to write as the object's body.
        object_key: Destination object key/path inside the bucket. Always
            confined under this account's own prefix regardless of what's
            passed here.
        content_type: MIME type to tag the object with.
    """
    bucket_name = _resolve_bucket()
    key = _scope_key(object_key)
    client = _client()
    client.put_object(
        Bucket=bucket_name,
        Body=content.encode("utf-8"),
        Key=key,
        ContentType=content_type,
        ACL="public-read",
    )
    return _object_url(bucket_name, key)


@mcp.tool()
def list_objects(prefix: str | None = None) -> list[str]:
    """List object keys under this account's own prefix, optionally filtered
    by a further sub-prefix. Can never see another account's objects.

    Args:
        prefix: Only return objects whose key starts with this (relative to
            this account's own root - you don't need to and can't include
            another account's name here).
    """
    bucket_name = _resolve_bucket()
    scoped_prefix = _scope_prefix(prefix)
    client = _client()
    keys: list[str] = []
    marker = ""
    while True:
        response = client.list_objects(Bucket=bucket_name, Prefix=scoped_prefix, Marker=marker)
        for item in response.get("Contents", []) or []:
            key = item.get("Key")
            if key:
                keys.append(key)
        if response.get("IsTruncated") != "true":
            break
        marker = response.get("NextMarker", "")
        if not marker:
            break
    return keys


@mcp.tool()
def download_object(object_key: str, local_path: str) -> str:
    """Download an object to a local file path and return that path.

    Args:
        object_key: Source object key/path inside the bucket. Always
            confined under this account's own prefix regardless of what's
            passed here - another account's objects can't be read this way.
        local_path: Local destination file path to write to.
    """
    bucket_name = _resolve_bucket()
    key = _scope_key(object_key)
    client = _client()
    try:
        response = client.get_object(Bucket=bucket_name, Key=key)
    except CosServiceError as exc:
        if exc.get_status_code() == 404:
            raise FileNotFoundError(f"object not found: {bucket_name}/{key}") from exc
        raise
    os.makedirs(os.path.dirname(os.path.abspath(local_path)) or ".", exist_ok=True)
    response["Body"].get_stream_to_file(local_path)
    return local_path


if __name__ == "__main__":
    mcp.run(transport="stdio")
